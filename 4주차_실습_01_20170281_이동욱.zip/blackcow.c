#include <stdio.h>
#include <stdlib.h>

void print_blackcow (void){
	printf("blackcow ");
}
