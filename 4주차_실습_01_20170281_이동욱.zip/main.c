#include <stdio.h>
#include "animal.h"


int main (void){
	print_dog();
	print_blackcow();
	print_turtle();
	

	return 0;
}
