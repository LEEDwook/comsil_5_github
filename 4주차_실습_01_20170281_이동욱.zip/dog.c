#include <stdio.h>
#include <stdlib.h>

void print_dog (void){
        printf("dog ");
}

