#ifndef ANIMAL_H
#define ANIMAL_H
void print_dog(void);
void print_blackcow(void);
void print_turtle (void);

#endif /*ANIMAL_H*/
